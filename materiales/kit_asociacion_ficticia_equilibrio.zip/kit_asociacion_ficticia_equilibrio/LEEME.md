# Kit de prácticas · Asociación Equilibrio (ficticia)

Asociación **ficticia** de personas con diabetes de Valdeclara (pueblo y comarca inventados) para practicar con JuntIA, DifundIA, SubvencIA y EncuestIA sin usar datos de ninguna asociación real. Todas las personas, direcciones, correos (dominio `.example`), cifras y la Fundación Horizonte Salud son inventados. Las cifras cuadran entre documentos (socios, cuentas, presupuesto).

## 0 · Perfil común (en las cuatro apps)

`0_perfil_comun/perfil_asociacion_equilibrio.json`, en el formato común `perfil-asociacion-pacientes`. Trae logo y colores, y carga completo en las cuatro apps (JuntIA desde la versión 1.1.0).

## 1 · JuntIA (comunicación interna)

| Tipo | Subir | Idea (copiar y pegar) |
|---|---|---|
| Acta de una reunión | `A_acta/notas_junta_12nov2026.txt` | Acta de la junta directiva del jueves 12 de noviembre de 2026 |
| Convocatoria de reunión | `B_convocatoria/acta_junta_8oct2026.docx` | Junta directiva el jueves 10 de diciembre a las 18:30 en la sede: presupuesto 2027, proyecto para la Fundación Horizonte Salud y balance del taller de cocina |
| Comunicado a voluntariado | `C_comunicado/info_carrera_solidaria_2027.docx` | Buscamos 25 personas voluntarias para la II Carrera Solidaria Valdeclara en Marcha del domingo 14 de marzo de 2027 |
| Boletín interno | `D_boletin/boletin_octubre_2026.docx` y `novedades_noviembre_2026.txt` | Boletín de noviembre: cómo fue el Día Mundial de la Diabetes, el taller de cocina de las fiestas y las próximas citas |

Las notas traen un correo para ver el enmascarado. En el acta, comprobad que la IA no añada acuerdos que no están en las notas (por ejemplo, el cambio de banco no se decidió).

## 2 · DifundIA (comunicación externa)

- Subir: el perfil, `programa_taller_cocina_navidad.docx` y, si se quiere, `boletin_octubre_2026.docx` (para el estilo).
- Idea: *Taller de cocina «Fiestas en equilibrio»: tres recetas para disfrutar de las fiestas en familia, pensado para personas con diabetes y quien cocina en casa. Plazas limitadas.*
- Fecha: 12/12/2026.
- El programa trae las ideas de salud entre comillas para que las afirmaciones salgan con cita comprobada (✓).

## 3 · SubvencIA (proyectos de financiación)

1. Convocatoria: `bases/bases_convocatoria_fundacion_horizonte_2027.pdf` (7 criterios, 100 puntos).
2. Proyecto: `proyecto/borrador_proyecto_aprende_a_cuidarte_2027.docx`. Es flojo a propósito: tiene 5 apartados de los 9 que piden las bases, unos objetivos vagos y ningún indicador.
3. Documentos de la asociación: `memoria_actividades_2025.docx` y `presupuesto_aprende_a_cuidarte_2027.docx` (aquí están los datos que el borrador no usa: lista de espera, consultas, encuesta 2025, desglose).
4. Recomendado: hacer el ciclo 0 (estructura) y después de 3 a 5 ciclos.

## 4 · EncuestIA (encuestas)

- Subir: `encuesta_talleres_aprende_a_cuidarte_2026.xlsx` (o el `.csv`, que es igual): 115 respuestas, 61 antes y 54 después, como si fuera una exportación de Google Forms.
- Columna de momento: **Momento** (Antes y Después). Columna de grupo: **Perfil**.
- Lo que se ve en clase: la marca temporal y el correo se excluyen solos; «Otro» (4 personas) no aparece por tener menos de 5; un comentario lleva un correo que se enmascara; hay una pregunta de varias opciones (separadas por «;») y dos preguntas abiertas para agrupar en temas.
